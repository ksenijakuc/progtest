#SXD20|20009|50525|50313|2013.10.22 17:17:18|progtest|0|19|78|
#TA andts_banners`2`48|andts_benefits`2`796|andts_callback`0`0|andts_catalog`14`3964|andts_content`10`6780|andts_exchange`0`0|andts_feedback`0`0|andts_infoblock`5`416|andts_modules`12`240|andts_news`5`49152|andts_reqbuy`0`0|andts_reqbuysell`0`0|andts_reqviewer`0`0|andts_roles`2`100|andts_roles_perms`12`156|andts_roles_users`2`18|andts_settings`11`992|andts_user_tokens`0`0|andts_users`1`120
#EOH

#	TC`andts_banners`utf8_general_ci	;
CREATE TABLE `andts_banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(5) NOT NULL,
  `link` varchar(50) NOT NULL,
  `source` varchar(30) NOT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`andts_banners`utf8_general_ci	;
INSERT INTO `andts_banners` VALUES 
(5,'image','','5.png',\N,\N),
(6,'image','','6.png',\N,\N)	;
#	TC`andts_benefits`utf8_general_ci	;
CREATE TABLE `andts_benefits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8	;
#	TD`andts_benefits`utf8_general_ci	;
INSERT INTO `andts_benefits` VALUES 
(1,'Все услуги компании застрахованы.','Наша компания предостtавляет своим клиентам не только услуги Квалифицированных специалистов, но и страхование ответственности. Это даёт Вам уверенность в том, что даже при возникновении ситуации фосмажора.','1.jpg',1),
(3,'Все услуги компании застрахованы дважды','Наша компания предостtавляет своим клиентам не только услуги Квалифицированных специалистов, но и страхование ответственности.','3.jpg',1)	;
#	TC`andts_callback`utf8_general_ci	;
CREATE TABLE `andts_callback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `call_time` varchar(100) DEFAULT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`andts_catalog`utf8_general_ci	;
CREATE TABLE `andts_catalog` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lvl` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `scope` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `content` text,
  `data` text,
  `map` text,
  `price` int(10) unsigned DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `street` varchar(50) DEFAULT NULL,
  `tract` varchar(50) DEFAULT NULL,
  `house` varchar(3) DEFAULT NULL,
  `corps` varchar(2) DEFAULT NULL,
  `floor` int(2) DEFAULT NULL,
  `floors` int(11) DEFAULT NULL,
  `square` float DEFAULT NULL,
  `square_2` float DEFAULT NULL,
  `rooms` int(1) DEFAULT NULL,
  `image` varchar(20) DEFAULT NULL,
  `virtour` varchar(100) DEFAULT NULL,
  `hot_status` int(1) DEFAULT '0',
  `hypothec_status` int(1) DEFAULT '0',
  `meta_title` tinytext,
  `meta_keywords` tinytext,
  `meta_description` tinytext,
  `ord` int(11) NOT NULL DEFAULT '10',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8	;
#	TD`andts_catalog`utf8_general_ci	;
INSERT INTO `andts_catalog` VALUES 
(1,0,1,16,1,'Загородная недвижимость','',\N,'',0,'','','','','',\N,\N,0,0,\N,'','',0,0,'','','',10,1),
(2,0,1,6,2,'Городская недвижимость','',\N,'',0,'','','','','',\N,\N,0,0,\N,'','',0,0,'','','',10,1),
(3,0,1,2,3,'Коммерческая недвижимость','',\N,'',0,'','','','','',\N,\N,0,0,\N,'','',0,0,'','','',10,1),
(4,0,1,4,4,'Готовый бизнес','',\N,'',0,'','','','','',\N,\N,0,0,\N,'','',0,0,'','','',10,1),
(5,1,2,11,1,'Коттеджи','',\N,'',0,'','','','','',\N,\N,0,0,\N,'','',0,0,'','','',1,1),
(11,2,5,6,1,'Коттедж 2','','','',1000000,'Екатеринбург','','19 км Сибирский тракт','','',12,\N,111,111,11,'11.jpg','',1,\N,'','','',2,1),
(9,2,3,4,1,'Коттедж','','','',12000,'Екатеринбург','','14 км Сибирский тракт','','',12,3,322.2,12,12,'9.jpg','',1,1,'','','',1,1),
(10,1,2,3,4,'Название объекта','',\N,'',100000,'Екатеринбург','','','','',\N,\N,0,0,\N,'10.jpg','',1,\N,'','','',1,1),
(12,2,7,8,1,'Коттедж 3','','','',343434,'Екатеринбург','','','','',56,\N,5,5,6,'12.jpg','',1,\N,'','','',3,1),
(13,2,9,10,1,'Коттедж 4','','','',34,'Екатеринбург','','','','',56,\N,5,5,6,'13.jpg','',1,1,'','','',4,1),
(14,1,2,5,2,'Квартиры','',\N,'',0,'','','','','',\N,\N,0,0,\N,'','',0,0,'','','',1,1),
(15,2,3,4,2,'Квартира на Фрунз 102','',\N,'',100000,'Екатеринбург','Фрунзе','','102','',5,\N,60,0,3,'15.jpg','',1,\N,'','','',1,1),
(16,1,12,15,1,'Участки','',\N,'',0,'','','','','',\N,\N,0,0,\N,'','',0,0,'Участки','','',2,1),
(17,2,13,14,1,'участок в поселке Лесные тропы','<p>\n	<strong>Коттеджный поселок &quot;Лесные тропы&quot;</strong> расположен в границах города (то есть земля в Екатеринбурге), южнее поселка Горный щит, на лесной поляне площадью 80 га. Площадь самого поселка составляет 18,5 га, которые поделены на 102 участка площадью от <strong>8</strong> до <strong>25</strong> соток. Проект предусматривает наличие зоны отдыха с прудом, детской и спортивной площадками; ограждение периметра металлическим забором из металлопрофиля с осуществлением контроля доступа на территорию; отсыпку дорог с твердым покрытием до участков; подведение электричества; в перспективе - газификация поселка.</p>\n<p>\n	Подробную информацию Вы можете смотреть на сайте <a href=\"http://www.lesnye-tropy.ru/\"><span class=\"info\">www.lesnye-tropy.ru</span></a></p>\n','<table>\n	<tbody>\n		<tr>\n			<th>\n				Тип объекта</th>\n			<td>\n				Вторичное</td>\n		</tr>\n		<tr class=\"even\">\n			<th>\n				Расположение</th>\n			<td>\n				г. Екатеринбург, Серова 28</td>\n		</tr>\n		<tr>\n			<th>\n				Общая площадь</th>\n			<td>\n				105 м<sup>2</sup></td>\n		</tr>\n		<tr class=\"even\">\n			<th>\n				Жилая площадь</th>\n			<td>\n				90 м<sup>2</sup></td>\n		</tr>\n		<tr>\n			<th>\n				Этаж</th>\n			<td>\n				7</td>\n		</tr>\n		<tr class=\"even\">\n			<th>\n				Количество комант</th>\n			<td>\n				3</td>\n		</tr>\n		<tr>\n			<th>\n				Цена</th>\n			<td>\n				3 700 000 руб.</td>\n		</tr>\n	</tbody>\n</table>\n','<script type=\"text/javascript\" charset=\"utf-8\" src=\"//api-maps.yandex.ru/services/constructor/1.0/js/?sid=Yvo_TCqTWD-JTi1Wc7OB1ATJ6MxiBRjg&width=600&height=450\"></script>',780000,'Екатеринбург','','Полевской тракт','','',0,\N,0,12,0,'17.jpg','',1,\N,'ЦН ДТС (екатеринбург) - участок в поселке Лесные тропы','ЦН ДТС (екатеринбург) - участок в поселке Лесные тропы','ЦН ДТС (екатеринбург) - участок в поселке Лесные тропы',1,1)	;
#	TC`andts_content`utf8_general_ci	;
CREATE TABLE `andts_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lvl` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  `scope` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `brief` text NOT NULL,
  `content` text NOT NULL,
  `module_id` int(11) DEFAULT NULL,
  `url` varchar(30) NOT NULL,
  `meta_title` tinytext NOT NULL,
  `meta_keywords` tinytext NOT NULL,
  `meta_description` tinytext NOT NULL,
  `ord` int(11) NOT NULL DEFAULT '10',
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8	;
#	TD`andts_content`utf8_general_ci	;
INSERT INTO `andts_content` VALUES 
(1,0,1,20,1,'Основные разделы','','',\N,'','','','',10,0),
(2,1,2,3,1,'Главная страница','','<h2>\n	О компании</h2>\n<p>\n	Наша компания предлагает Вам полный список услуг связанных с покупкой недвижимости в Екатеринбурге и Свердловской области. Основанная в 1993 году имеющая богатейший опыт работы на рынке жилой и коммерческой недвижимости Екатеринбурга компания не стоит на месте и постоянно развивается из года в год, открывая своим клиентам все больше возможностей для качественной аренды жилья, покупки или продажи квартир, земельных участков, коттеджей, день за днем увеличивая качество предлагаемых услуг.</p>\n<p>\n	С нашей помощью Вы легко приобретете или продадите недвижимость. Екатеринбург &mdash; крупный мегаполис, и у нас накоплена большая база данных. Наша команда это команда высококвалифицированных специалистов, каждый из которых имеет &laquo;за плечами&raquo; многие годы работы на рынке недвижимости. Продажа квартир в Екатеринбурге &ndash; одно из основных направлений деятельности агентства недвижимости &laquo;Диал&raquo;.</p>\n',\N,'index','Главная страница','','',1,0),
(3,1,4,5,1,'Загородная недвижимость','','',3,'catalog/1','Загородная недвижимость','','',2,1),
(4,1,6,7,1,'Недвижимость в городе','','',3,'catalog/2','Недвижимость в городе','','',3,1),
(5,1,8,9,1,'Коммерческая недвижимость','','',3,'catalog/3','Коммерческая недвижимость','','',4,1),
(6,1,10,11,1,'Готовый бизнес','','',3,'catalog/4','Готовый бизнес','','',5,1),
(7,1,12,13,1,'Услуги','','<h2>\n	Преимущества нашей компании</h2>\n<p>\n	<img alt=\"\" src=\"/images/frontend/tmp/news-item1.jpg\" /></p>\n<p>\n	Наша компания предлагает Вам полный список услуг связанных с покупкой недвижимости в Екатеринбурге и Свердловской области. Основанная в 1993 году имеющая богатейший опыт работы на рынке жилой и коммерческой недвижимости Екатеринбурга компания не стоит на месте и постоянно развивается из года в год, открывая своим клиентам все больше возможностей для качественной аренды жилья, покупки или продажи квартир, земельных участков, коттеджей, день за днем</p>\n<p>\n	Наша компания предлагает Вам полный список услуг связанных с покупкой недвижимости в <a href=\"#\">Екатеринбурге и Свердловской области</a>. Основанная в 1993 году имеющая богатейший опыт работы на рынке жилой и коммерческой недвижимости Екатеринбурга компания не стоит на месте и постоянно развивается из года в год, открывая своим клиентам все больше возможностей для качественной аренды жилья, покупки или продажи квартир, земельных участков, коттеджей, день за днем увеличивая качество предлагаемых услуг.</p>\n<blockquote>\n	То, что называется недвижимостью, &ndash; твердая почва, на которой можно построить дом, &ndash; служит основанием почти для всех грехов этого мира.(Натаниел Готорн)</blockquote>\n<h2>\n	Примеры оформления текстовых списков</h2>\n<h3>\n	Оформление нумированного списка:</h3>\n<ol>\n	<li>\n		Сначала вы выбираете квартиру, которую хотите купить.</li>\n	<li>\n		Юридическая проверка квартиры.</li>\n	<li>\n		Если вы планируете купить квартиру с привлечением ипотечного кредита, то лучше проконсультируйтесь в любом из офисов</li>\n</ol>\n<h3>\n	Оформление маркированного списка:</h3>\n<ul>\n	<li>\n		Сначала вы выбираете квартиру, которую хотите купить.</li>\n	<li>\n		Юридическая проверка квартиры.</li>\n	<li>\n		Если вы планируете купить квартиру с привлечением ипотечного кредита, то лучше проконсультируйтесь в любом из офисов</li>\n</ul>\n<h2>\n	Пример оформления таблицы.</h2>\n<table>\n	<tbody>\n		<tr>\n			<th>\n				Тип объекта</th>\n			<td>\n				Вторичное</td>\n		</tr>\n		<tr class=\"even\">\n			<th>\n				Расположение</th>\n			<td>\n				г. Екатеринбург, Серова 28</td>\n		</tr>\n		<tr>\n			<th>\n				Общая площадь</th>\n			<td>\n				105 м<sup>2</sup></td>\n		</tr>\n		<tr class=\"even\">\n			<th>\n				Жилая площадь</th>\n			<td>\n				90 м<sup>2</sup></td>\n		</tr>\n		<tr>\n			<th>\n				Этаж</th>\n			<td>\n				7</td>\n		</tr>\n		<tr class=\"even\">\n			<th>\n				Количество комант</th>\n			<td>\n				3</td>\n		</tr>\n		<tr>\n			<th>\n				Цена</th>\n			<td>\n				3 700 000 руб.</td>\n		</tr>\n	</tbody>\n</table>\n<p>\n	&nbsp;</p>\n',\N,'services','Услуги','','',6,1),
(8,1,14,17,1,'О компании','','',\N,'about','О компании','','',7,0),
(9,1,18,19,1,'Контакты','','',\N,'contacts','Контакты','','',8,0),
(10,2,15,16,1,'Полезные статьи','','',\N,'articles','Полезные статьи','','',1,1)	;
#	TC`andts_exchange`utf8_general_ci	;
CREATE TABLE `andts_exchange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `object_data_1` text NOT NULL,
  `object_data_2` text NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`andts_feedback`utf8_general_ci	;
CREATE TABLE `andts_feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `message` text NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`andts_infoblock`utf8_general_ci	;
CREATE TABLE `andts_infoblock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `content` text NOT NULL,
  `wysiwyg` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8	;
#	TD`andts_infoblock`utf8_general_ci	;
INSERT INTO `andts_infoblock` VALUES 
(1,'Шапка :: Телефон','(343) 344-77-77',0),
(2,'Подвал :: Копирайты','ЦН Дом твоей семьи',0),
(3,'Подвал :: Адрес','г.Екатеринбург, ул. Московская 195, офис 1134',0),
(4,'Подвал :: Телефон','+7 (343) 344-77-77',0),
(5,'Подвал :: Счетчики','<p><img alt=\"\" src=\"/images/frontend/tmp/counter1.jpg\"></p>',1)	;
#	TC`andts_modules`utf8_general_ci	;
CREATE TABLE `andts_modules` (
  `mid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8	;
#	TD`andts_modules`utf8_general_ci	;
INSERT INTO `andts_modules` VALUES 
(1,'content'),
(2,'infoblock'),
(6,'benefits'),
(5,'banner'),
(3,'catalog'),
(7,'feedback'),
(8,'callback'),
(9,'reqviewer'),
(10,'exchange'),
(11,'reqbuy'),
(12,'reqbuysell'),
(13,'news')	;
#	TC`andts_news`utf8_general_ci	;
CREATE TABLE `andts_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `brief_text` text NOT NULL,
  `full_text` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8	;
#	TD`andts_news`utf8_general_ci	;
INSERT INTO `andts_news` VALUES 
(1,'Спецслужбы США взломали почту президента Мексики','Агентство национальной безопасности США в 2010 году получило доступ к электронной почте президента Мексики, сообщает Der Spiegel со ссылкой на материалы, переданные журналистам бывшим сотрудником ЦРУ Эдвардом Сноуденом.','<p>\n	Как говорится в документе, подразделение АНБ, занимающееся особо сложными заданиями в области получения доступа к той или иной информации, в мае 2010 года отчиталось о взломе почтового сервера администрации президента Мексики. Помимо доступа к переписке Фелипе Кальдерона, который занимал высший пост в Мексике с 2006 по 2012 годы, АНБ получило доступ к письмам мексиканских министров, которые касались дипломатических, экономических и политических вопросов.</p>\n<p>\n	Операция по взлому почтового сервера получила название &laquo;Flatliquid&raquo;. Имеют ли американские спецслужбы доступ к переписке президента Мексики в настоящее время, не сообщается.</p>\n<p>\n	Ранее из документов, полученных журналистами от Сноудена, уже стало известно, что АНБ летом 2012 года занималось слежкой за перепиской кандидата в президенты Мексики Энрико Пенья Ньето, который в конце прошлого года выиграл президентские выборы в стране. Продолжилась ли слежка за мексиканским политиком после победы на выборах, не сообщалось. По словам Пенья Ньето, президент США Барак Обама пообещал ему расследовать инцидент со слежкой за его перепиской.</p>\n<p>\n	Помимо мексиканских властей АНБ занималось мониторингом электронной переписки президента Бразилии Дилмы Русеф. После того, как сведения о слежке за Русеф были преданы огласке, она отменила запланированный визит в США. Бразильское правительство осудило действия американских спецслужб и потребовало объяснений.</p>\n<p>\n	Эдвард Сноуден передал журналистам нескольких изданий секретные документы ЦРУ и АНБ в июне 2013 года, после чего получил временное убежище в России. Помимо слежки за руководителями иностранных государств в материалах говорилось о существовании глобальной системы слежения за интернет-перепиской пользователей и телефонными переговорами под названием PRISM, созданной АНБ.</p>\n','1.jpg','2013-10-22 09:34:13',1),
(3,'Без признаков жизни','Есть ли среди двух тысяч уже открытых планет за пределами Солнечной системы те, на которых существует жизнь? Насколько уникальна в этом отношении Земля? Как измерить вес Млечного пути, «не вставая с дивана»? Как продвигаются поиски гравитационных волн и когда они наконец будут обнаружены? Об этом и многом другом читайте в свежем обзоре астрономических препринтов на «Ленте.ру».','Чарльз Кокелл, ученый университетского Центра Астробиологии в Эдинбурге, выступил в роли скептика в вопросе поиска внеземной жизни. В недавно опубликованной работе он подробно и обстоятельно доказывает свою гипотезу о том, что большинство обитаемых (или потенциально обитаемых) миров не будут проявлять каких-либо признаков жизни, которые можно обнаружить с Земли. Другими словами, даже если на какой-то далекой планете нашей Галактики и есть жизнь, то мы этого, скорее всего, просто не заметим.  Работа Кокелла вносит некий отрезвляющий элемент в красочные мечты многочисленных искателей жизни на внесолнечных планетах. Действительно, количество открытых экзопланет уже приближается к двум тысячам, и это наводит на мысли о том, что непосредственное открытие какой-либо формы жизни или ее следов вне Земли уже не за горами. Но Кокелл призывает задуматься — а сумеем ли мы в принципе «узнать» обитаемую планету, если таковая окажется в поле зрения современных телескопов? Он считает, что вряд ли.  Для начала стоит отметить, что под выражением «обитаемый мир» (habitable world) астрономы понимают не планету, на которой есть жизнь, а планету, для нее в принципе пригодную. Речь идет о том типе живой природы, который нам знаком и понятен — то есть об органической жизни, похожей на земную. Поэтому традиционный астрофизический критерий обитаемости планеты (когда говорят, что она находится в своей «зоне обитаемости») — это возможность существования на ней жидкой воды, твердой поверхности и плотной атмосферы.  Однако, говорит Кокелл, этого еще очень мало для реального развития органической жизни. Как минимум необходимы и известный химический состав, и определенная геология (например, наличие горячих источников). На планете должно быть достаточно много углерода — главного строительного материала органической жизни. И конечно, должны присутствовать другие незаменимые для жизни элементы: азот, кислород, фосфор, сера и так далее. То есть потенциальная обитаемость планеты (исходя из указанного критерия) еще не означает, что на ней действительно возможна жизнь.  Но даже в случае подходящего химического состава обнаруженная планета может оказаться еще настолько молодой, что более или менее заметная жизнь на ней еще просто не успела развиться. Так, согласно существующим представлениям, земная жизнь зародилась лишь через миллиард лет после образования Солнечной системы, что немало даже по космическим меркам. Кроме того, жизни мало возникнуть — требуется еще и время для ее развития до устойчивого состояния. Поэтому возможна, к примеру, и такая ситуация: эволюция орбиты конкретной планеты делает ее пригодной для жизни лишь в некоторые, относительно короткие, промежутки времени, в остальное же время она выходит за пределы зоны обитаемости своей звезды.','3.jpg','2013-10-22 08:47:15',1),
(4,'Торрент-трекер IsoHunt закрылся по договоренности с правообладателями','Торрент-трекер IsoHunt прекратит свою работу в течение ближайших семи дней. Об этом говорится в тексте досудебного соглашения, заключенного 17 октября между представителями трекера и Американской ассоциацией кинокомпаний (MPAA).','<div class=\"b-text clearfix\" itemprop=\"articleBody\">\n	<p>\n		Торрент-трекер IsoHunt прекратит свою работу в&nbsp;течение ближайших семи дней. Об&nbsp;этом говорится в&nbsp;тексте досудебного соглашения, <a href=\"http://ru.scribd.com/doc/176947007/Isohunt-Mpaa-110\" target=\"_blank\">заключенного</a> 17&nbsp;октября между представителями трекера и&nbsp;Американской ассоциацией кинокомпаний (MPAA).</p>\n	<p>\n		Кроме самого ресурса <a href=\"http://isohunt.com/\" target=\"_blank\">isohunt.com</a> закрытию подлежат также все связанные с&nbsp;ним сайты (<a href=\"http://podtropolis.com/\" target=\"_blank\">podtropolis.com</a>, <a href=\"http://torrentbox.com/\" target=\"_blank\">torrentbox.com</a> и&nbsp;<a href=\"http://ed2k-it.com/\" target=\"_blank\">ed2k-it.com</a>).</p>\n	<p>\n		Как говорится в&nbsp;документе, владелец IsoHunt Гэри Фанг (Gary Fung) также обязан выплатить представителям MPAA компенсацию за&nbsp;нанесенный деятельностью его сайтов ущерб. Общий размер выплат составит 110 миллионов долларов США.</p>\n	<p>\n		Конфликт между торрент-трекером и&nbsp;Американской ассоциацией кинокомпаний, объединяющей крупнейших кинопроизводителей США, тянулся с&nbsp;2006&nbsp;года. Представители организации обвиняли ресурс в&nbsp;нарушении авторских прав и&nbsp;распространении пиратского контента. Руководство IsoHunt все обвинения отвергало, заявляя, что сайт работает по&nbsp;принципу интернет-поисковика. По словам администрации трекера, ресурс просто собирает ссылки на&nbsp;контент и не&nbsp;обязан проводить обязательные проверки легальности размещенных по&nbsp;таким ссылкам материалов.</p>\n	<p>\n		Владелец IsoHunt должен был предстать перед судом 5&nbsp;ноября этого года. Если&nbsp;бы заключить соглашение с&nbsp;правообладателями не&nbsp;удалось, и&nbsp;дело попало&nbsp;бы в&nbsp;суд, Фангу мог грозить штраф до&nbsp;600 миллионов долларов.</p>\n</div>\n<p>\n	&nbsp;</p>\n','4.jpg','2013-10-22 14:04:46',0),
(5,'Создатель «Во все тяжкие» признал пользу интернет-пиратства','Создатель телесериала «Во все тяжкие» Винс Гиллиган (Vince Gilligan) заявил, что интернет-пиратство помогло сделать шоу популярнее и позволило посмотреть сериал большему числу людей. Об этом Гиллиган рассказал 18 октября в своем интервью «Би-би-си».','<p>\n	Создатель телесериала &laquo;Во&nbsp;все тяжкие&raquo; Винс Гиллиган (Vince Gilligan) заявил, что интернет-пиратство помогло сделать шоу популярнее и&nbsp;позволило посмотреть сериал большему числу людей. Об&nbsp;этом Гиллиган <a href=\"http://www.bbc.co.uk/newsbeat/24550832\" target=\"_blank\">рассказал</a> 18&nbsp;октября в&nbsp;своем интервью &laquo;Би-би-си&raquo;.</p>\n<p>\n	По&nbsp;словам Гиллигана, у&nbsp;интернет-пиратства есть как положительная, так и&nbsp;отрицательная сторона. &laquo;Незаконное распространение фильмов в&nbsp;интернете безусловно является проблемой. Если&nbsp;бы пиратства не&nbsp;существовало, люди, работавшие над проектом, получили&nbsp;бы больше денег. Однако, если быть до&nbsp;конца честным, пиратство помогло сделать бренд сериала более узнаваемым. Фильм посмотрели люди, которые могли и не узнать о&nbsp;его существовании&raquo;,&nbsp;&mdash; заявил сценарист &laquo;Во&nbsp;все тяжкие&raquo;.</p>\n','','0000-00-00 00:00:00',1),
(7,'Создатель телесериала «Во все тяжкие» Винс Гиллиган (Vince Gilligan) заявил','По словам Гиллигана, у интернет-пиратства есть как положительная, так и отрицательная сторона. «Незаконное распространение фильмов в интернете безусловно является проблемой. Если бы пиратства не существовало, люди, работавшие над проектом, получили бы больше денег. Однако, если быть до конца честным, пиратство помогло сделать бренд сериала более узнаваемым. Фильм посмотрели люди, которые могли и не узнать о его существовании», — заявил сценарист «Во все тяжкие».','<p>\n	По словам Гиллигана, у интернет-пиратства есть как положительная, так и отрицательная сторона. &laquo;Незаконное распространение фильмов в интернете безусловно является проблемой. Если бы пиратства не существовало, люди, работавшие над проектом, получили бы больше денег. Однако, если быть до конца честным, пиратство помогло сделать бренд сериала более узнаваемым. Фильм посмотрели люди, которые могли и не узнать о его существовании&raquo;, &mdash; заявил сценарист &laquo;Во все тяжкие&raquo;.</p>\n<p>\n	По словам Гиллигана, у интернет-пиратства есть как положительная, так и отрицательная сторона. &laquo;Незаконное распространение фильмов в интернете безусловно является проблемой. Если бы пиратства не существовало, люди, работавшие над проектом, получили бы больше денег. Однако, если быть до конца честным, пиратство помогло сделать бренд сериала более узнаваемым. Фильм посмотрели люди, которые могли и не узнать о его существовании&raquo;, &mdash; заявил сценарист &laquo;Во все тяжкие&raquo;.</p>\n','','2013-10-22 14:00:10',1),
(8,'Новость','Новость','<p>\n	Новость</p>\n<p>\n	Новость</p>\n<p>\n	Новость</p>\n','','2013-10-22 14:18:03',1)	;
#	TC`andts_reqbuy`utf8_general_ci	;
CREATE TABLE `andts_reqbuy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `comment` text,
  `object_data` text NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TC`andts_reqbuysell`utf8_general_ci	;
CREATE TABLE `andts_reqbuysell` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `offer_type` varchar(10) NOT NULL,
  `object_type` varchar(50) NOT NULL,
  `object_data` text NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`andts_reqviewer`utf8_general_ci	;
CREATE TABLE `andts_reqviewer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `view_date` date NOT NULL,
  `view_time` varchar(10) DEFAULT NULL,
  `object_data` text NOT NULL,
  `catalog_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `time` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8	;
#	TC`andts_roles`utf8_general_ci	;
CREATE TABLE `andts_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8	;
#	TD`andts_roles`utf8_general_ci	;
INSERT INTO `andts_roles` VALUES 
(2,'admin','Администратор'),
(1,'login','Роль для входа на сайт')	;
#	TC`andts_roles_perms`utf8_general_ci	;
CREATE TABLE `andts_roles_perms` (
  `module_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `permission` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`andts_roles_perms`utf8_general_ci	;
INSERT INTO `andts_roles_perms` VALUES 
(1,2,1),
(2,2,1),
(3,2,1),
(6,2,1),
(5,2,1),
(7,2,1),
(8,2,1),
(9,2,1),
(10,2,1),
(11,2,1),
(12,2,1),
(13,2,1)	;
#	TC`andts_roles_users`utf8_general_ci	;
CREATE TABLE `andts_roles_users` (
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TD`andts_roles_users`utf8_general_ci	;
INSERT INTO `andts_roles_users` VALUES 
(1,1),
(1,2)	;
#	TC`andts_settings`utf8_general_ci	;
CREATE TABLE `andts_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `param` varchar(50) NOT NULL,
  `value` text,
  `show` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8	;
#	TD`andts_settings`utf8_general_ci	;
INSERT INTO `andts_settings` VALUES 
(1,'Название сайта','site_name','АН ДТС',0),
(2,'Путь до изображений','image_path','/images/admin/',0),
(3,'Путь до CSS','css_path','/css/admin/',0),
(4,'Путь до JS','js_path','/js/admin/',0),
(5,'Путь до PHP пакетов','packages_path','/packages/',0),
(54,'Email для получения писем ФОС','fos_email','mr--alex@yandex.ru',0),
(57,'Email для получения запросов на осмотр','reqviewer_email','mr--alex@yanex.ru',0),
(56,'Email для получения запросов обратного звонка','callback_email','mr--alex@yandex.ru',0),
(58,'Email для получения запросов на обмен','exchange_email','mr--alex@yandex.ru',0),
(59,'Email для получения запросов на покупку','reqbuy_email','mr--alex@yandex.ru',0),
(60,'Email для получения запросов на покупку/продажу','reqbuysell_email','mr--alex@yandex.ru',0)	;
#	TC`andts_user_tokens`utf8_general_ci	;
CREATE TABLE `andts_user_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(32) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8	;
#	TC`andts_users`utf8_general_ci	;
CREATE TABLE `andts_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `post` varchar(50) DEFAULT NULL,
  `photo` varchar(10) DEFAULT NULL,
  `delivery_addres` varchar(50) DEFAULT NULL,
  `distributor` int(1) NOT NULL DEFAULT '0',
  `inn` varchar(15) DEFAULT NULL,
  `company` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `legal_address` varchar(50) DEFAULT NULL,
  `contract` varchar(15) DEFAULT NULL,
  `discount` int(11) DEFAULT NULL,
  `confirm_status` int(1) NOT NULL DEFAULT '0',
  `attache_status` int(1) NOT NULL DEFAULT '0',
  `last_login` int(10) DEFAULT NULL,
  `reg_date` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8	;
#	TD`andts_users`utf8_general_ci	;
INSERT INTO `andts_users` VALUES 
(1,'admin','fd76a26cdc145066bc44633edefea0c1','Администратор','mr--alex@yandex.ru',\N,\N,\N,\N,0,\N,\N,'',\N,\N,\N,1,1,1382439710,123456)	;
